package com.codefactory.team3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
